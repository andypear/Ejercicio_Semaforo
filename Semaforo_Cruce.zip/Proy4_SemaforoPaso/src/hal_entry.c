#include "hal_data.h"

ioport_level_t P0_05Status;
ioport_level_t P0_06Status;
const bsp_delay_units_t bsp_delay_units = BSP_DELAY_UNITS_MILLISECONDS;     /* Define the units to be used with the software delay function */
uint32_t delay = 0, i=0;
uint32_t flag = 0, nParpadeos = 5, delayParpadeos = 200, delayAmarillo = 1000, delayEspera = 10000;                                                 /* Calculate the delay in terms of bsp_delay_units */
void secuencia();
void inicializacion();

void hal_entry(void) {
    inicializacion();

    while(1)
    {
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW);
    }
}

void button_callback_SW4(external_irq_callback_args_t *p_args) {
    delay = 10000;
    secuencia();
}
void button_callback_SW5(external_irq_callback_args_t *p_args) {
    delay = 20000;
    secuencia();
}

void secuencia() {
    for (i = 0; i < nParpadeos; i++) {
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);
        R_BSP_SoftwareDelay(delayParpadeos, bsp_delay_units);
        g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW);
        R_BSP_SoftwareDelay(delayParpadeos, bsp_delay_units);
    }
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_LOW);
    R_BSP_SoftwareDelay(delayAmarillo, bsp_delay_units);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_LOW);
    R_BSP_SoftwareDelay(delay, bsp_delay_units);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_LOW);
    R_BSP_SoftwareDelay(delayAmarillo, bsp_delay_units);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_LOW);

    R_BSP_SoftwareDelay(delayEspera, bsp_delay_units);
}

void inicializacion() {
    g_external_irq10.p_api->open(g_external_irq10.p_ctrl,g_external_irq10.p_cfg);
    g_external_irq11.p_api->open(g_external_irq11.p_ctrl,g_external_irq11.p_cfg);

    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00, IOPORT_LEVEL_HIGH);
}
